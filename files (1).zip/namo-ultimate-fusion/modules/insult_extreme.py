def insult_extreme():
    print("💢 [Insult Extreme] โหมดด่าหยาบสุดขีด: พร้อมปลุกแรงอารมณ์ด้วยวาจารุนแรง!")