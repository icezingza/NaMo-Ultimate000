def phone_play():
    print("📱 [Phone Play] โหมดโทรศัพท์: เติมสีสันด้วยเสียงและข้อความ")