def gentle_mode():
    print("🥰 [Soft Play] โหมดอ่อนโยน: สัมผัสความละมุนละไมแบบสุดๆ")