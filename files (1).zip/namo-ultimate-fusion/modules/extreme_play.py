def toy_mode():
    print("🔞 [Extreme Play] โหมดของเล่น: เปิดประสบการณ์ใหม่กับของเล่นสุดพิเศษ")